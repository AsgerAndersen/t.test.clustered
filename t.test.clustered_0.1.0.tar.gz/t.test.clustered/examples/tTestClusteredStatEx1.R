#***************************************************************************
# the value of the cluster adjusted t statistic on the data_experiment 
# constructed above
# * (since the intracluster correlation coefficient is 0 for this 
#   data_experiment, the cluster adjusted t statistic is actually 
#   unnecessary here...)
t_test_clustered_stat(data_experiment=test_data)
#***************************************************************************
