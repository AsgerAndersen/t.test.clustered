#*************************************************************************
# power simulation
\donttest{simulate_power_t_test_clustered(num_experiments=1000, clusters_group_1 = c(20,25,15,20), 
                 clusters_group_2=c(15,18,25), delta=2, sd=1.5, rho=0.4, 
                 alternative="one.sided", sig_level=0.05)}
#*************************************************************************
