#***************************************************************************
# the p value of a two sided cluster adjusted t test
t_test_clustered_pval(test_data,alternative="two.sided")
#***************************************************************************
